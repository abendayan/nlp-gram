the program test.py tries to derive the sentences listed in sentences.txt with the given grammar.
add the sentences you want to check to sentences.txt, and replace grammar.txt with your grammar.

to run: python test.py grammar.txt sentences.txt
